from AccessControl import ModuleSecurityInfo

ModuleSecurityInfo('sys').declarePublic('breakpoint')